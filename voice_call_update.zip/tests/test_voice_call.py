"""CPU-only protocol tests: no CUDA, network downloads, or model weights."""
import base64
import io
from pathlib import Path
import struct
import sys
import tempfile
import threading
import time
import unittest
import wave
import os
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from fastapi.testclient import TestClient
from voice_call_server import create_app, parse_args, validate_wav, load_config, prepare_decoder
from voice_web_demo import InferenceCancelled, check_cancelled, make_prompt


def recording(seconds=0.6, rate=16000):
    output = io.BytesIO()
    with wave.open(output, "wb") as stream:
        stream.setparams((1, 2, rate, 0, "NONE", "not compressed"))
        stream.writeframes(struct.pack("<h", 1000) * int(seconds * rate))
    return output.getvalue()


class FakeBackend:
    def __init__(self, folder):
        self.folder = Path(folder)
        self.lock = threading.Lock()
        self.started = threading.Event()
        self.cancelled = threading.Event()
        self.block_first = False
        self.calls = []
        self.inspected = []

    def load(self):
        pass

    def answer(self, source, use_rag, knowledge, knowledge_file, language, history, cancel_event=None):
        self.calls.append((len(history), use_rag, knowledge))
        if self.block_first and len(self.calls) == 1:
            self.started.set()
            if not cancel_event.wait(4):
                raise RuntimeError("Test did not interrupt the first request")
            self.cancelled.set()
            raise InferenceCancelled()
        check_cancelled(cancel_event)
        path = self.folder / "reply.wav"
        path.write_bytes(recording())
        record = {"text": f"客服回复 {len(history) + 1}",
                  "question_tokens": "<|begin_of_audio|><|audio_42|><|audio_71|><|end_of_audio|>",
                  "assistant_tokens": "reply"}
        return [], str(path), knowledge, "done", list(history) + [record]

    def decode_input_wav(self, tokens):
        self.inspected.append(tokens)
        return recording(rate=22050)


class CallTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.args = parse_args(["--output-dir", self.temp.name])
        self.backend = FakeBackend(self.temp.name)
        self.config = {"title": "测试客服", "greeting": "您好", "language": "zh", "system_prompt": "客服设定",
                       "knowledge_text": "售后服务时间为九点到十八点", "silence_ms": 850, "min_speech_ms": 260}

    def client(self):
        return TestClient(create_app(self.args, self.config, self.backend))

    def wait_ready(self, client):
        for _ in range(100):
            if client.get("/api/health").json()["state"] == "ready":
                return
            time.sleep(0.01)
        self.fail("Backend did not become ready")

    def send_turn(self, socket, turn):
        socket.send_json({"type": "utterance", "id": turn})
        socket.send_bytes(recording())

    def reply(self, socket):
        for _ in range(8):
            message = socket.receive_json()
            if message["type"] == "reply":
                return message
            self.assertNotEqual(message["type"], "error", message)
        self.fail("No reply")

    def test_auto_turns_history_knowledge_and_fresh_call(self):
        with self.client() as client:
            self.wait_ready(client)
            self.assertEqual(client.get("/").status_code, 200)
            for name in ("call.js", "style.css", "capture-worklet.js", "audio-engine.mjs"):
                self.assertEqual(client.get("/assets/" + name).status_code, 200)
            with client.websocket_connect("/api/call") as socket:
                self.assertEqual(socket.receive_json()["type"], "ready")
                self.assertFalse(client.get("/api/health").json()["available"])
                self.send_turn(socket, 1)
                first = self.reply(socket)
                self.assertEqual(first["text"], "客服回复 1")
                self.assertTrue(first["audio"])
                self.assertEqual(first["input_tokens"], [42, 71])
                self.assertEqual(self.backend.inspected, [])
                socket.send_json({"type": "inspect_input", "id": 1})
                preview = socket.receive_json()
                self.assertEqual((preview["type"], preview["id"]), ("input_audio", 1))
                self.assertEqual(base64.b64decode(preview["audio"]), recording(rate=22050))
                self.assertEqual(self.backend.inspected, [[42, 71]])
                self.send_turn(socket, 2)
                self.assertEqual(self.reply(socket)["text"], "客服回复 2")
                socket.send_json({"type": "hangup"})
            self.assertEqual(self.backend.calls, [(0, True, self.config["knowledge_text"]), (1, True, self.config["knowledge_text"])])
            with client.websocket_connect("/api/call") as socket:
                self.assertEqual(socket.receive_json()["type"], "ready")
                self.send_turn(socket, 1)
                self.assertEqual(self.reply(socket)["text"], "客服回复 1")

    def test_interrupt_cancels_and_discards_old_reply(self):
        self.backend.block_first = True
        with self.client() as client:
            self.wait_ready(client)
            with client.websocket_connect("/api/call") as socket:
                socket.receive_json()
                self.send_turn(socket, 1)
                self.assertEqual(socket.receive_json(), {"type": "thinking", "id": 1})
                self.assertTrue(self.backend.started.wait(2))
                socket.send_json({"type": "interrupt"})
                self.send_turn(socket, 2)
                reply = self.reply(socket)
                self.assertEqual(reply["id"], 2)
                self.assertTrue(self.backend.cancelled.wait(1))
                self.assertEqual(self.backend.calls[-1][0], 0)

    def test_hangup_cancels_worker_and_releases_call(self):
        self.backend.block_first = True
        with self.client() as client:
            self.wait_ready(client)
            with client.websocket_connect("/api/call") as socket:
                socket.receive_json()
                self.send_turn(socket, 1)
                self.assertEqual(socket.receive_json()["type"], "thinking")
                self.assertTrue(self.backend.started.wait(2))
                socket.send_json({"type": "hangup"})
            self.assertTrue(self.backend.cancelled.wait(2))
            self.assertTrue(client.get("/api/health").json()["available"])

    def test_one_call_at_a_time_and_origin_rejection(self):
        with self.client() as client:
            self.wait_ready(client)
            with client.websocket_connect("/api/call") as first:
                first.receive_json()
                with client.websocket_connect("/api/call") as second:
                    self.assertEqual(second.receive_json()["type"], "error")
            from starlette.websockets import WebSocketDisconnect
            with self.assertRaises(WebSocketDisconnect):
                with client.websocket_connect("/api/call", headers={"origin": "https://unrelated.example"}):
                    pass

    def test_reject_audio_without_metadata(self):
        with self.client() as client:
            self.wait_ready(client)
            with client.websocket_connect("/api/call") as socket:
                socket.receive_json()
                socket.send_bytes(recording())
                self.assertEqual(socket.receive_json()["type"], "error")

    def test_wav_validation_and_customer_prompt(self):
        validate_wav(recording(), 30)
        for value in (b"not-wav", recording(1, 8000), recording(1)[:-20]):
            with self.assertRaises(ValueError):
                validate_wav(value, 30)
        with self.assertRaises(ValueError):
            validate_wav(recording(2), 1)
        prompt = make_prompt([], "question", "reference", "zh", "门店客服设定")
        self.assertIn("门店客服设定", prompt)
        self.assertIn("reference", prompt)
        self.assertIn("question", prompt)

    def test_missing_decoder_fails_before_model_loading(self):
        self.args.flow_path = self.temp.name
        with self.assertRaisesRegex(RuntimeError, "Decoder"):
            prepare_decoder(self.args)

    def test_download_flag_disables_offline_for_process_and_checks_files(self):
        self.args.flow_path = self.temp.name
        self.args.download_models = True

        def download(repo, local_dir, allow_patterns, max_workers):
            self.assertEqual(repo, "zai-org/glm-4-voice-decoder")
            for key in ("HF_HUB_OFFLINE", "TRANSFORMERS_OFFLINE", "HF_DATASETS_OFFLINE"):
                self.assertEqual(os.environ[key], "0")
            for name in allow_patterns:
                (Path(local_dir) / name).write_bytes(b"test weight bytes " * 10)

        with patch.dict(os.environ, {"HF_HUB_OFFLINE": "1"}), patch.dict(
            sys.modules, {"huggingface_hub": SimpleNamespace(snapshot_download=download)}
        ):
            prepare_decoder(self.args)
        self.assertTrue((Path(self.temp.name) / "flow.pt").is_file())


if __name__ == "__main__":
    unittest.main()
