import assert from "node:assert/strict";
import { VoiceActivityDetector, encodeWav } from "../call_web/audio-engine.mjs";
import { VoiceCall } from "../call_web/call.js";

assert.equal(typeof VoiceCall.prototype.start, "function");
assert.equal(typeof VoiceCall.prototype.stop, "function");
const frame = amplitude => new Float32Array(480).fill(amplitude);
const vad = new VoiceActivityDetector(48000);
const events = [];
for (let i = 0; i < 50; i++) events.push(...vad.feed(frame(0.0001)));
for (let i = 0; i < 60; i++) events.push(...vad.feed(frame(0.05)));
for (let i = 0; i < 100; i++) events.push(...vad.feed(frame(0.0001)));
assert.deepEqual(events.map(event => event.type), ["start", "utterance"]);
const wav = encodeWav(events[1].samples, 48000);
const header = new DataView(wav);
assert.equal(header.getUint32(24, true), 16000);
assert.equal(header.getUint16(22, true), 1);
assert.equal(header.getUint16(34, true), 16);
assert.equal(header.getUint32(40, true), wav.byteLength - 44);

const clicks = new VoiceActivityDetector(48000);
const noise = clicks.feed(frame(0.1));
for (let i = 0; i < 120; i++) noise.push(...clicks.feed(frame(0.0001)));
assert.equal(noise.length, 0);

// Room noise above the old fixed floor must not start or hold a turn open.
const noisyRoom = new VoiceActivityDetector(48000);
const ambientEvents = [];
for (let i = 0; i < 50; i++) ambientEvents.push(...noisyRoom.feed(frame(0.008)));
assert.deepEqual(ambientEvents, []);
for (let i = 0; i < 60; i++) ambientEvents.push(...noisyRoom.feed(frame(0.05)));
for (let i = 0; i < 100; i++) ambientEvents.push(...noisyRoom.feed(frame(0.008)));
assert.deepEqual(ambientEvents.map(event => event.type), ["start", "utterance"]);

// A fan that starts during speech, plus short clicks during the pause.
const changingRoom = new VoiceActivityDetector(48000);
const changedEvents = [];
for (let i = 0; i < 40; i++) changedEvents.push(...changingRoom.feed(frame(0.001)));
for (let i = 0; i < 60; i++) changedEvents.push(...changingRoom.feed(frame(0.05)));
for (let i = 0; i < 115; i++) changedEvents.push(...changingRoom.feed(frame(i % 30 === 0 ? 0.05 : 0.008)));
assert.deepEqual(changedEvents.map(event => event.type), ["start", "utterance"]);

const manual = new VoiceActivityDetector(48000);
for (let i = 0; i < 40; i++) manual.feed(frame(0.001));
for (let i = 0; i < 60; i++) manual.feed(frame(0.05));
assert.equal(manual.finish()?.type, "utterance");
assert.equal(manual.finish(), null);

const bounded = new VoiceActivityDetector(48000, { maxSeconds: 1 });
const longEvents = [];
for (let i = 0; i < 300; i++) longEvents.push(...bounded.feed(frame(0.05)));
assert.equal(longEvents.filter(event => event.type === "utterance").length, 1);
for (let i = 0; i < 100; i++) bounded.feed(frame(0.0001));
const next = [];
for (let i = 0; i < 40; i++) next.push(...bounded.feed(frame(0.05)));
for (let i = 0; i < 100; i++) next.push(...bounded.feed(frame(0.0001)));
assert.equal(next.filter(event => event.type === "utterance").length, 1);

// Marking a newer utterance must discard a late reply before any playback.
const call = Object.create(VoiceCall.prototype);
call.active = true; call.epoch = 1; call.turn = 2;
call.showReply = () => { throw new Error("Stale reply should be discarded"); };
call.onMessage({ type: "reply", id: 1, text: "old", audio: "old" }, 1);
call.active = false;
call.onMessage({ type: "reply", id: 2, text: "closed", audio: "closed" }, 1);

// Hanging up must release the actual capture/playback handles, not just the UI.
const elements = new Map();
globalThis.document = {
  body: { dataset: {} }, documentElement: { style: { setProperty() {} } },
  getElementById(id) { if (!elements.has(id)) elements.set(id, {}); return elements.get(id); },
};
globalThis.window = {};
globalThis.WebSocket = { OPEN: 1 };

function callAwaitingReply() {
  const call = Object.create(VoiceCall.prototype);
  const messages = [], phases = [];
  Object.assign(call, {
    active: true, epoch: 1, turn: 0, playToken: 0, awaitingReply: false, speaking: false, pauseUntil: 0,
    vad: new VoiceActivityDetector(48000), context: { sampleRate: 48000 },
    socket: { readyState: 1, bufferedAmount: 0, send(data) {
      if (typeof data === "string") messages.push(JSON.parse(data));
    } },
    phase(name) { phases.push(name); },
    showReply() {},
    showInputClip(wav, trigger) {
      assert.equal(new DataView(wav).getUint32(24, true), 16000);
      assert.equal(trigger, "自动发送");
    },
  });
  const feed = (amplitude, count) => {
    for (let i = 0; i < count; i++) call.onAudio(frame(amplitude), 1);
  };
  feed(0.001, 50);
  feed(0.05, 60);
  feed(0.001, 90);
  return { call, feed, messages, phases };
}

// Even speech-length noise must not supersede a reply, including during decoding.
const guarded = callAwaitingReply();
const feedNoiseTurn = () => {
  guarded.feed(0.05, 60);
  guarded.feed(0.001, 90);
  assert.deepEqual(guarded.messages, [{ type: "utterance", id: 1 }]);
};
guarded.call.onMessage({ type: "thinking", id: 1 }, 1);
feedNoiseTurn();
assert.equal(guarded.phases.at(-1), "thinking");

let finishDecode, playback;
const decoded = new Promise(resolve => { finishDecode = resolve; });
const player = { connect() {}, start() {} };
Object.assign(guarded.call.context, {
  decodeAudioData() { return decoded; },
  async resume() {},
  createBufferSource() { return player; },
});
guarded.call.playAudio = (...args) => { playback = VoiceCall.prototype.playAudio.apply(guarded.call, args); };
guarded.call.onMessage({ type: "reply", id: 1, text: "answer", audio: "AA==" }, 1);
assert.equal(guarded.call.speaking, true);
feedNoiseTurn();
finishDecode({});
await playback;
assert.equal(guarded.phases.at(-1), "speaking");
feedNoiseTurn();

player.onended();
assert.equal(guarded.phases.at(-1), "listening");
guarded.call.pauseUntil = 0; // Advance past the playback echo guard.
guarded.feed(0.05, 60);
guarded.feed(0.001, 90);
assert.deepEqual(guarded.messages, [{ type: "utterance", id: 1 }, { type: "utterance", id: 2 }]);

const ended = { tracks: 0, socket: 0, context: 0, nodes: 0, playback: 0 };
const sent = [];
const connected = Object.create(VoiceCall.prototype);
Object.assign(connected, {
  active: true, epoch: 1, playToken: 0,
  socket: { readyState: 1, send(data) { sent.push(JSON.parse(data)); }, close() { ended.socket++; } },
  player: { stop() { ended.playback++; }, disconnect() {} },
  capture: { port: {}, disconnect() { ended.nodes++; } },
  source: { disconnect() { ended.nodes++; } }, silent: { disconnect() { ended.nodes++; } },
  stream: { getTracks() { return [{ stop() { ended.tracks++; } }]; } },
  context: { close() { ended.context++; return Promise.resolve(); } },
});
connected.stop();
assert.deepEqual(ended, { tracks: 1, socket: 1, context: 1, nodes: 3, playback: 1 });
assert.deepEqual(sent, [{ type: "hangup" }]);
assert.equal(connected.active, false);
assert.equal(connected.stream, null);
assert.equal(connected.context, null);
assert.equal(connected.capture, null);
delete globalThis.document; delete globalThis.window; delete globalThis.WebSocket;
