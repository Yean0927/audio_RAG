# 浏览器语音对话

## 一键客服通话（新入口）

在项目目录执行：

```bash
source .venv/bin/activate
python -m pip install -r requirements-web.txt -c requirements-server.txt -c constraints-server.txt
bash start_voice_call.sh
```

如果旧的 `voice_web_demo.py` 还占用 7860 端口，先在其终端按 Ctrl+C 停止。
启动脚本会仅在服务进程内设置 `HF_HUB_OFFLINE=0`、`TRANSFORMERS_OFFLINE=0`、`HF_DATASETS_OFFLINE=0`。
缺少 Decoder 时自动下载 `config.yaml`、`flow.pt`、`hift.pt`；主模型和 Tokenizer 在加载时按需下载。
这解决了下载日志中的 `OfflineModeIsEnabled`。网络仍需能够访问 Hugging Face；如果继续遇到网络错误，保留完整终端日志以便诊断。

通过下面的 SSH 转发访问，麦克风使用 Mac 上的浏览器：

```bash
ssh -N -L 7860:127.0.0.1:7860 root@192.168.10.10
```

打开 http://localhost:7860。客服就绪后，页面只有一个“开始通话”按钮。
允许麦克风后自动监听，停顿约 850 ms 后自动发送。回答生成和播放期间暂停语音分句，播放结束后自动恢复监听。
如果停顿检测没有及时结束录音，可以点「说完了，发送」。展开「查看本轮录音」可以播放实际发送的音频，查看这一轮的语音 token，并按需解码试听。
同一按钮在通话中变为“挂断通话”；挂断会关闭麦克风、停止播放并取消在途生成。
页面关闭或连接中断也会清理本地麦克风；服务端不再发送该通话的回复。

当前为自动轮流对话：整轮模型回答生成后播放，尚未实现逐 token 的低延迟语音流。真实延迟取决于服务器上的模型推理和 Decoder。
语音检测使用浏览器本地的自适应能量阈值，开启回声消除和降噪；嘈杂环境或外放回声下可能误触发，需要结合真实麦克风调整停顿阈值或使用耳机。
一台服务实例同时接待一路通话，其他页面会显示客服正在通话。

首次运行会从 `call_config.example.json` 创建 `call_config.json`；后者用于服务器端配置，不出现在用户页面。
可以设置客服名称、开场白、中文/英文、客服话术和 UTF-8 知识库文件路径。
`knowledge_file` 留空时进行自由客服对话；填写本地文本路径时自动启用 SONAR 跨模态检索。
修改配置后重启服务。默认仍为主模型 GPU 0 / 语音组件和可选 SONAR GPU 1。

只检查权重文件和客服配置，不加载 GPU 模型：

```bash
python voice_call_server.py --check
```

录音与结果仍保存在 `answer_data/calls/`，不随挂断删除。

以下保留原先手动录音页面的说明，便于调试。

`setup_glm_server.py` 安装和检查环境；`voice_web_demo.py` 启动网页。
网页支持麦克风录音、上传音频、文字及语音回答、最近三轮上下文，以及可选的 SONAR 语音检索。
录完后点击发送，再等待完整回答；当前版本不提供边说边播或打断。

## 服务器准备

在服务器项目目录激活 `.venv` 后，先完成环境检查：

```bash
python setup_glm_server.py
python -m pip install -r requirements-web.txt -c requirements-server.txt -c constraints-server.txt
python -m pip check
huggingface-cli download zai-org/glm-4-voice-decoder --local-dir ./glm-4-voice-decoder
```

主模型与语音 Tokenizer 首次加载时自动从 Hugging Face 下载。开启知识库后，SONAR 会另行下载编码器。
也可用 `--model-path`、`--tokenizer-path`、`--flow-path` 指定已经下载的本地目录。

## 启动和连接

服务器：

```bash
python voice_web_demo.py
```

Mac 另开本地终端，建立 SSH 转发，并保持该终端打开：

```bash
ssh -N -L 7860:127.0.0.1:7860 root@192.168.10.10
```

Mac 浏览器打开 http://localhost:7860，允许麦克风权限，录音结束后点击发送。
浏览器的麦克风需要安全上下文；通过 SSH 转发访问 localhost 可满足这一要求。
服务默认只监听服务器的 127.0.0.1，不创建 Gradio 公网分享链接。

默认将主模型以 NF4 量化加载到 GPU 0，把语音 Tokenizer、Decoder 和可选的 SONAR 放到 GPU 1。
没有修改仓库原来的 GLM 模型加载方法；双卡分配仅作用于此网页入口。

单卡可用 `--speech-device cuda:0`；显存充裕时可用 `--quantization bf16`。
默认每条录音最长 30 秒，回答最多生成 768 个文本与语音 token；可通过命令行参数调整。

## 知识库

默认关闭知识库，可直接自由对话。需要检索时，勾选“使用知识库回答”，然后粘贴内容或上传 UTF-8 的 TXT/Markdown。
文件优先于粘贴文本；知识库限制为 1 MB / 20 万字。
知识库会按 600 字符分块，使用 SONAR 语音/文本编码器做跨模态检索，以平方欧氏距离选择最近的四块。
每次请求只选择一种语言的编码器，切换语言时重新载入对应编码器。

录音、回答及参考内容保存在 `answer_data/web/<随机编号>/`。点击“开始新对话”清空页面上下文，磁盘记录仍保留。

## 验证范围

本地可验证依赖解析、网页构建、会话和提示词逻辑。实际权重下载、双 GPU 推理、量化质量、中文语音和 SONAR 检索需要在服务器验证。
