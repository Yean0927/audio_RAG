"""One-button voice-call UI using the existing GLM-Voice GPU backend."""
from __future__ import annotations

import asyncio
import base64
from contextlib import asynccontextmanager
import io
import json
import logging
import os
from pathlib import Path
import re
import threading
import uuid
import wave
from urllib.parse import urlparse

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from voice_web_demo import ROOT, VoiceBackend, InferenceCancelled, create_parser, validate_args

LOG = logging.getLogger("voice-call")
ASSETS = ROOT / "call_web"
INPUT_TOKEN = re.compile(r"<\|audio_(\d+)\|>")


def load_config(path):
    path = Path(path)
    if not path.exists():
        path.write_text((ROOT / "call_config.example.json").read_text(encoding="utf-8"), encoding="utf-8")
    config = json.loads(path.read_text(encoding="utf-8"))
    if config.get("language", "zh") not in ("zh", "en"):
        raise ValueError("call_config.json language must be zh or en")
    knowledge = config.get("knowledge_file", "")
    if knowledge:
        file = Path(knowledge)
        if not file.is_absolute():
            file = ROOT / file
        if not file.is_file() or file.stat().st_size > 1_000_000:
            raise ValueError("knowledge_file must be an existing UTF-8 file under 1 MB")
        config["knowledge_text"] = file.read_text(encoding="utf-8-sig").strip()
        if len(config["knowledge_text"]) > 200_000:
            raise ValueError("Knowledge text must be under 200,000 characters")
    else:
        config["knowledge_text"] = ""
    config["silence_ms"] = max(500, min(1800, int(config.get("silence_ms", 850))))
    config["min_speech_ms"] = max(200, min(800, int(config.get("min_speech_ms", 260))))
    return config


def missing_decoder(args):
    folder = Path(args.flow_path)
    return [name for name in ("config.yaml", "flow.pt", "hift.pt")
            if not (folder / name).is_file() or (folder / name).stat().st_size < 64]


def prepare_decoder(args):
    if missing_decoder(args) and args.download_models:
        # This flag explicitly enables downloads for this project process only.
        for key in ("HF_HUB_OFFLINE", "TRANSFORMERS_OFFLINE", "HF_DATASETS_OFFLINE"):
            os.environ[key] = "0"
        from huggingface_hub import snapshot_download
        LOG.info("Downloading missing decoder files into %s", args.flow_path)
        snapshot_download(
            "zai-org/glm-4-voice-decoder", local_dir=args.flow_path,
            allow_patterns=["config.yaml", "flow.pt", "hift.pt"], max_workers=2,
        )
    missing = missing_decoder(args)
    if missing:
        raise RuntimeError(
            f"Decoder 文件缺失：{', '.join(missing)}。运行 bash start_voice_call.sh 自动下载，"
            "或先 unset HF_HUB_OFFLINE TRANSFORMERS_OFFLINE HF_DATASETS_OFFLINE，"
            f"再下载到 {Path(args.flow_path).resolve()}。"
        )
    for name in ("flow.pt", "hift.pt"):
        with (Path(args.flow_path) / name).open("rb") as stream:
            if stream.read(80).startswith(b"version https://git-lfs"):
                raise RuntimeError(f"{name} 是 Git LFS 指针，请下载真实权重。")


def validate_wav(data, max_seconds):
    if len(data) > (max_seconds + 1) * 32000 + 4096:
        raise ValueError("这段语音过长，请分成短句。")
    try:
        with wave.open(io.BytesIO(data), "rb") as stream:
            if (stream.getnchannels(), stream.getsampwidth(), stream.getframerate()) != (1, 2, 16000):
                raise ValueError("音频格式无效，请重新开始通话。")
            frames = stream.getnframes()
            if not 0 < frames <= (max_seconds + 0.5) * 16000:
                raise ValueError("语音为空或过长，请重试。")
            if len(stream.readframes(frames)) != frames * 2:
                raise ValueError("语音传输不完整，请重新说一次。")
    except (wave.Error, EOFError) as error:
        raise ValueError("语音格式无效，请重新说一次。") from error


def create_app(args, config, backend=None):
    backend = backend or VoiceBackend(args)
    args.system_prompt = config.get("system_prompt", "")
    phase = {"state": "loading"}
    initialize_task = None
    inference_lock = asyncio.Lock()
    call_slot = asyncio.Lock()

    def initialize_sync():
        # Injected backends are used by protocol tests, without CUDA or model weights.
        if isinstance(backend, VoiceBackend):
            prepare_decoder(args)
        with backend.lock:
            backend.load()

    async def initialize():
        phase["state"] = "loading"
        try:
            await asyncio.to_thread(initialize_sync)
        except Exception:
            LOG.exception("客服初始化失败；修复后可在页面点击重新连接，或重启服务。")
            phase["state"] = "error"
        else:
            phase["state"] = "ready"
            LOG.info("VOICE CALL READY — open http://localhost:%s through your SSH tunnel", args.port)

    def start_initialization():
        nonlocal initialize_task
        if initialize_task is None or initialize_task.done():
            initialize_task = asyncio.create_task(initialize())

    @asynccontextmanager
    async def lifespan(app):
        start_initialization()
        yield
        if initialize_task is not None and not initialize_task.done():
            initialize_task.cancel()

    app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
    app.mount("/assets", StaticFiles(directory=ASSETS), name="assets")

    @app.get("/")
    async def index():
        return FileResponse(ASSETS / "index.html", headers={"Cache-Control": "no-store"})

    @app.get("/api/health")
    async def health():
        return {"state": phase["state"], "available": not call_slot.locked(),
                "title": config.get("title", "语音客服")}

    @app.post("/api/retry")
    async def retry():
        if phase["state"] == "error":
            phase["state"] = "loading"
            start_initialization()
        return {"state": phase["state"]}

    @app.websocket("/api/call")
    async def call(socket: WebSocket):
        origin = socket.headers.get("origin")
        if origin and urlparse(origin).netloc != socket.headers.get("host"):
            await socket.close(code=1008)
            return
        await socket.accept()
        if phase["state"] != "ready" or call_slot.locked():
            await socket.send_json({"type": "error", "message": "客服暂未就绪或正在通话，请稍后再试。"})
            await socket.close(code=1013)
            return
        await call_slot.acquire()
        session = uuid.uuid4().hex
        incoming = Path(args.output_dir).resolve() / "incoming" / session
        incoming.mkdir(parents=True, exist_ok=True)
        history = []
        current_event = None
        current_id = 0
        last_id = 0
        pending_id = None
        last_input = None
        inspection = None
        closed = False
        jobs = set()

        async def send(message):
            if not closed:
                await socket.send_json(message)

        def infer(path, saved_history, event):
            with backend.lock:
                if event.is_set():
                    raise InferenceCancelled()
                return backend.answer(
                    str(path), bool(config.get("knowledge_text")), config.get("knowledge_text", ""),
                    None, config.get("language", "zh"), saved_history, cancel_event=event,
                )

        async def respond(turn, path, event):
            nonlocal history, last_input
            try:
                async with inference_lock:
                    if event.is_set() or closed:
                        return
                    await send({"type": "thinking", "id": turn})
                    result = await asyncio.to_thread(infer, path, list(history), event)
                    if event.is_set() or closed or turn != current_id:
                        return
                    _, audio, _, _, updated = result
                    record = updated[-1]
                    encoded = base64.b64encode(Path(audio).read_bytes()).decode("ascii") if audio else None
                    if event.is_set() or closed or turn != current_id:
                        return
                    tokens = [int(value) for value in INPUT_TOKEN.findall(record["question_tokens"])]
                    last_input = (turn, tokens)
                    await send({"type": "reply", "id": turn, "text": record["text"],
                                "audio": encoded, "input_tokens": tokens})
                    history = updated
            except InferenceCancelled:
                LOG.info("Call %s turn %s interrupted", session, turn)
            except (WebSocketDisconnect, RuntimeError) as error:
                if closed or event.is_set():
                    return
                LOG.exception("Call inference failed")
                try:
                    await send({"type": "error", "id": turn, "message": "这次回答暂时遇到问题，请重新说一次。"})
                except Exception:
                    pass
            except Exception:
                LOG.exception("Call inference failed")
                if not closed and not event.is_set():
                    await send({"type": "error", "id": turn, "message": "这次回答暂时遇到问题，请重新说一次。"})

        def decode_input(tokens):
            with backend.lock:
                return backend.decode_input_wav(tokens)

        async def inspect_input(turn, tokens):
            try:
                async with inference_lock:
                    if closed or turn != current_id:
                        return
                    audio = await asyncio.to_thread(decode_input, tokens)
                if not closed and turn == current_id:
                    await send({"type": "input_audio", "id": turn, "audio": base64.b64encode(audio).decode("ascii")})
            except Exception:
                LOG.exception("Input token playback failed")
                if not closed and turn == current_id:
                    try:
                        await send({"type": "input_audio", "id": turn, "message": "这轮的语音 token 暂时无法解码。"})
                    except (RuntimeError, WebSocketDisconnect):
                        pass

        try:
            await send({"type": "ready", "greeting": config.get("greeting", ""),
                        "language": config.get("language", "zh"), "silence_ms": config["silence_ms"],
                        "min_speech_ms": config["min_speech_ms"], "max_audio_seconds": args.max_audio_seconds})
            while True:
                packet = await socket.receive()
                if packet["type"] == "websocket.disconnect":
                    break
                if packet.get("text") is not None:
                    if len(packet["text"]) > 4096:
                        raise ValueError("通话消息过长。")
                    message = json.loads(packet["text"])
                    kind = message.get("type")
                    if kind in ("interrupt", "hangup"):
                        if current_event:
                            current_event.set()
                        pending_id = None
                        if kind == "hangup":
                            break
                    elif kind == "utterance":
                        turn = message.get("id")
                        if isinstance(turn, bool) or not isinstance(turn, int) or not last_id < turn < 1_000_000_000:
                            raise ValueError("通话序号无效，请重新连接。")
                        pending_id = turn
                        last_id = turn
                    elif kind == "ping":
                        await send({"type": "pong"})
                    elif kind == "inspect_input":
                        turn = message.get("id")
                        if (last_input and turn == current_id == last_input[0] and last_input[1]
                                and (inspection is None or inspection.done())):
                            inspection = asyncio.create_task(inspect_input(*last_input))
                        elif not inspection or inspection.done():
                            await send({"type": "input_audio", "id": turn, "message": "这轮的语音 token 尚未就绪。"})
                elif packet.get("bytes") is not None:
                    if pending_id is None:
                        raise ValueError("语音没有对应的通话消息，请重新连接。")
                    data = packet["bytes"]
                    validate_wav(data, args.max_audio_seconds)
                    if current_event:
                        current_event.set()
                    current_id, pending_id = pending_id, None
                    current_event = threading.Event()
                    path = incoming / f"{current_id}.wav"
                    path.write_bytes(data)
                    task = asyncio.create_task(respond(current_id, path, current_event))
                    jobs.add(task)
                    task.add_done_callback(jobs.discard)
        except WebSocketDisconnect:
            pass
        except (ValueError, json.JSONDecodeError) as error:
            await send({"type": "error", "message": str(error)})
        finally:
            closed = True
            if current_event:
                current_event.set()
            call_slot.release()
            try:
                await socket.close()
            except RuntimeError:
                pass
            LOG.info("Call %s ended", session)

    return app


def parse_args(argv=None):
    parser = create_parser()
    parser.description = __doc__
    parser.set_defaults(output_dir=str(ROOT / "answer_data/calls"), max_new_tokens=512)
    parser.add_argument("--config", default=str(ROOT / "call_config.json"))
    parser.add_argument("--download-models", action="store_true", help="Download missing decoder weights and enable online model loading in this process")
    parser.add_argument("--check", action="store_true", help="Check decoder files and configuration without loading GPU models")
    return validate_args(parser.parse_args(argv), parser)


def main():
    args = parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    os.chdir(ROOT)
    if args.download_models:
        for key in ("HF_HUB_OFFLINE", "TRANSFORMERS_OFFLINE", "HF_DATASETS_OFFLINE"):
            os.environ[key] = "0"
    config = load_config(args.config)
    if args.check:
        prepare_decoder(args)
        print("Decoder 文件和客服配置检查通过。GPU 模型尚未加载。")
        return
    import uvicorn
    app = create_app(args, config)
    uvicorn.run(app, host=args.host, port=args.port, ws_max_size=(args.max_audio_seconds + 1) * 32000 + 8192)


if __name__ == "__main__":
    main()
