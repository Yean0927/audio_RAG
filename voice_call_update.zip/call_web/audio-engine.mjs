// Pure audio/turn-detection functions, shared with the protocol tests.
export function rms(samples) {
  let sum = 0;
  for (const value of samples) sum += value * value;
  return Math.sqrt(sum / Math.max(1, samples.length));
}

export function joinFrames(frames) {
  const result = new Float32Array(frames.reduce((sum, frame) => sum + frame.length, 0));
  let offset = 0;
  for (const frame of frames) { result.set(frame, offset); offset += frame.length; }
  return result;
}

export function encodeWav(samples, sourceRate, targetRate = 16000) {
  const count = Math.floor(samples.length * targetRate / sourceRate);
  const buffer = new ArrayBuffer(44 + count * 2);
  const view = new DataView(buffer);
  const text = (offset, value) => [...value].forEach((char, i) => view.setUint8(offset + i, char.charCodeAt(0)));
  text(0, "RIFF"); view.setUint32(4, 36 + count * 2, true); text(8, "WAVE");
  text(12, "fmt "); view.setUint32(16, 16, true); view.setUint16(20, 1, true);
  view.setUint16(22, 1, true); view.setUint32(24, targetRate, true);
  view.setUint32(28, targetRate * 2, true); view.setUint16(32, 2, true); view.setUint16(34, 16, true);
  text(36, "data"); view.setUint32(40, count * 2, true);
  const ratio = sourceRate / targetRate;
  for (let i = 0; i < count; i++) {
    const start = Math.floor(i * ratio), end = Math.min(samples.length, Math.max(start + 1, Math.floor((i + 1) * ratio)));
    let value = 0;
    for (let j = start; j < end; j++) value += samples[j];
    value = Math.max(-1, Math.min(1, value / (end - start)));
    view.setInt16(44 + i * 2, Math.round(value * (value < 0 ? 32768 : 32767)), true);
  }
  return buffer;
}

export class VoiceActivityDetector {
  constructor(rate, { silenceMs = 850, minSpeechMs = 260, maxSeconds = 30 } = {}) {
    this.rate = rate; this.silenceMs = silenceMs; this.minSpeechMs = minSpeechMs;
    this.maxSeconds = maxSeconds;
    this.noise = 0.001;
    this.calibrationMs = 0;
    this.calibrationMinimum = Infinity;
    this.reset();
  }
  reset() {
    this.active = false; this.frames = []; this.preRoll = []; this.preSamples = 0;
    this.candidateMs = 0; this.voicedMs = 0; this.quietMs = 0; this.samples = 0;
    this.waitForQuiet = false;
    this.voicedRunMs = 0;
    this.stableLevel = 0;
    this.stableMs = 0;
  }

  finish() {
    if (!this.active) return null;
    const event = this.voicedMs >= this.minSpeechMs
      ? { type: "utterance", samples: joinFrames(this.frames) }
      : { type: "discard" };
    this.reset();
    return event;
  }

  feed(frame, playing = false) {
    const level = rms(frame), ms = frame.length * 1000 / this.rate, events = [];
    // Measure room noise before classifying it as speech. Retain the audio in
    // the pre-roll so a caller who speaks immediately keeps the start of the turn.
    const calibrating = this.calibrationMs < 180;
    if (calibrating) {
      this.calibrationMs += ms;
      this.calibrationMinimum = Math.min(this.calibrationMinimum, level);
      this.noise = Math.max(0.001, Math.min(0.02, this.calibrationMinimum));
    }
    // A new, steady, low-level sound can appear after the call is calibrated.
    // Treat that stable level as background once it persists.
    if (level <= 0.02) {
      if (this.stableMs && Math.abs(level - this.stableLevel) <= Math.max(0.0005, this.stableLevel * 0.25)) {
        this.stableMs += ms;
      } else {
        this.stableLevel = level;
        this.stableMs = ms;
      }
    } else {
      this.stableMs = 0;
    }
    if (this.stableMs >= 200) this.noise = Math.max(this.noise, this.stableLevel);
    const threshold = Math.max(0.005, Math.min(0.035, this.noise * 1.5 + 0.001)) * (playing ? 1.6 : 1);
    const voiced = level > threshold;
    if (this.waitForQuiet) {
      this.quietMs = voiced ? 0 : this.quietMs + ms;
      if (this.quietMs > 400) this.reset();
      return events;
    }
    if (!this.active) {
      if (!calibrating && !voiced) this.noise = this.noise * 0.97 + level * 0.03;
      this.preRoll.push(frame); this.preSamples += frame.length;
      while (this.preSamples > this.rate * 0.32 && this.preRoll.length > 1) this.preSamples -= this.preRoll.shift().length;
      if (calibrating) return events;
      this.candidateMs = voiced ? this.candidateMs + ms : 0;
      const onsetMs = this.stableMs >= 100 ? 200 : playing ? 180 : 110;
      if (this.candidateMs >= onsetMs) {
        this.active = true; this.frames = [...this.preRoll]; this.samples = this.preSamples;
        this.voicedMs = this.candidateMs; this.quietMs = 0;
        events.push({ type: "start" });
      }
      return events;
    }
    this.frames.push(frame); this.samples += frame.length;
    this.quietMs += ms;
    this.voicedRunMs = voiced ? this.voicedRunMs + ms : 0;
    if (voiced) this.voicedMs += ms;
    // Brief clicks should not restart the end-of-speech timer.
    if (this.voicedRunMs >= 65) this.quietMs = 0;
    const full = this.samples >= this.rate * (this.maxSeconds - 0.1);
    if (this.quietMs >= this.silenceMs || full) {
      events.push(this.finish());
      if (full) this.waitForQuiet = true;
    }
    return events;
  }
}
