import { VoiceActivityDetector, encodeWav, rms } from "./audio-engine.mjs";

const $ = id => document.getElementById(id);
const decodeBase64 = encoded => Uint8Array.from(atob(encoded), char => char.charCodeAt(0));
const titles = {
  idle: ["随时为您解答", "点击开始，像打电话一样交流"],
  connecting: ["正在接通", "正在为您建立语音连接"],
  listening: ["我在听，请讲", "说完停顿片刻，我会自动回答"],
  recording: ["正在聆听", "您可以自然地表达您的需求"],
  thinking: ["正在为您解答", "稍等片刻，我正在整理回复"],
  speaking: ["客服正在回复", "听完回复后，可以继续提问"],
  error: ["暂时无法接通", "请稍后重试"],
};

export class VoiceCall {
  constructor() {
    this.active = false; this.epoch = 0; this.turn = 0; this.playToken = 0;
    this.health = null; this.speaking = false; this.pauseUntil = 0;
    this.awaitingReply = false;
    $("call-button").addEventListener("click", () => this.toggle());
    $("send-now").addEventListener("click", () => {
      if (!this.active || this.awaitingReply || this.speaking) return;
      this.handleAudioEvent(this.vad?.finish(), "手动发送");
    });
    $("decode-input").addEventListener("click", () => {
      if (!this.active || this.socket?.readyState !== WebSocket.OPEN) return;
      $("decode-input").disabled = true;
      $("decode-status").textContent = "正在解码…";
      this.send({ type: "inspect_input", id: this.turn });
    });
    this.previews = [$("input-recording"), $("decoded-input")];
    for (const player of this.previews) {
      player.addEventListener("play", () => {
        if (this.speaking || this.vad?.active) { player.pause(); return; }
        for (const other of this.previews) if (other !== player) other.pause();
        this.vad?.reset();
      });
      player.addEventListener("pause", () => { this.pauseUntil = performance.now() + 180; });
      player.addEventListener("ended", () => { this.pauseUntil = performance.now() + 180; });
    }
    window.addEventListener("pagehide", () => this.stop());
    this.refreshHealth();
    this.poll = setInterval(() => { if (!this.active) this.refreshHealth(); }, 2500);
  }

  phase(name, caption = "") {
    document.body.dataset.phase = name;
    $("send-now").hidden = name !== "recording";
    const [heading, description] = titles[name] || titles.idle;
    $("heading").textContent = heading; $("description").textContent = description;
    if (caption) $("caption").textContent = caption;
  }

  async refreshHealth() {
    if (this.active) return;
    try {
      const response = await fetch("/api/health", { cache: "no-store" });
      if (!response.ok) throw new Error("连接失败");
      const data = await response.json();
      if (this.active) return;
      this.health = data;
      $("brand").textContent = data.title || "语音客服";
      document.title = data.title || "语音客服";
      const ready = data.state === "ready" && data.available;
      $("service-dot").classList.toggle("ready", ready);
      $("service-label").textContent = ready ? "在线" : data.state === "error" ? "暂未就绪" : data.available ? "正在准备" : "正在通话";
      $("call-button").disabled = data.state === "loading" || (data.state === "ready" && !data.available);
      $("button-label").textContent = ready ? "开始通话" : data.state === "error" ? "重新连接" : data.available ? "客服准备中" : "客服正在通话";
      if (ready && document.body.dataset.phase !== "error") $("caption").textContent = "点击后允许麦克风权限，即可开始交流。";
      else if (data.state === "loading") $("caption").textContent = "客服正在准备，请稍候。";
      else if (data.state === "error") { this.phase("error", "客服暂未就绪，请稍后重新连接。"); }
    } catch (_) {
      if (this.active) return;
      this.health = null;
      $("service-dot").classList.remove("ready"); $("service-label").textContent = "连接中";
      $("call-button").disabled = false; $("button-label").textContent = "重新连接";
      $("caption").textContent = "暂时无法连接客服，请稍后重试。";
    }
  }

  async toggle() {
    if (this.active) { this.stop(); return; }
    if (!this.health || this.health.state !== "ready") {
      $("call-button").disabled = true;
      try { await fetch("/api/retry", { method: "POST" }); } catch (_) { /* health shows connection status */ }
      await this.refreshHealth();
      return;
    }
    await this.start();
  }

  async start() {
    const epoch = ++this.epoch;
    this.active = true; this.turn = 0;
    this.awaitingReply = false;
    this.pauseUntil = 0;
    this.clearInput();
    this.phase("connecting", "请允许浏览器使用麦克风。");
    $("call-button").disabled = false; $("button-label").textContent = "挂断通话";
    $("reply").hidden = true;
    try {
      if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) throw new Error("请通过 localhost 或 HTTPS 打开页面后使用麦克风。");
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) throw new Error("当前浏览器暂不支持语音通话。");
      // Create/resume on the button gesture so later replies can play automatically.
      const context = new AudioContext(); this.context = context;
      if (!context.audioWorklet || !window.AudioWorkletNode) throw new Error("当前浏览器暂不支持语音通话。");
      await context.resume();
      const hello = await this.connectSocket(epoch);
      if (!this.active || this.epoch !== epoch) return;
      const stream = await navigator.mediaDevices.getUserMedia({ audio: {
        channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true,
      } });
      if (!this.active || this.epoch !== epoch) { stream.getTracks().forEach(track => track.stop()); return; }
      this.stream = stream;
      await context.audioWorklet.addModule("/assets/capture-worklet.js");
      if (!this.active || this.epoch !== epoch) return;
      this.vad = new VoiceActivityDetector(context.sampleRate, {
        silenceMs: hello.silence_ms, minSpeechMs: hello.min_speech_ms, maxSeconds: hello.max_audio_seconds,
      });
      this.source = context.createMediaStreamSource(stream);
      this.capture = new AudioWorkletNode(context, "microphone-capture");
      this.silent = context.createGain(); this.silent.gain.value = 0;
      this.source.connect(this.capture).connect(this.silent).connect(context.destination);
      this.capture.port.onmessage = event => this.onAudio(new Float32Array(event.data), epoch);
      stream.getAudioTracks().forEach(track => track.addEventListener("ended", () => {
        if (this.active && this.epoch === epoch) this.fail("麦克风连接已断开，请重新开始通话。");
      }));
      this.startedAt = Date.now(); this.timer = setInterval(() => this.updateTimer(), 1000);
      this.updateTimer();
      this.phase("listening", "通话已接通，您可以直接说话。");
      this.language = hello.language === "en" ? "en-US" : "zh-CN";
      if (hello.greeting) {
        this.showReply(hello.greeting);
        this.speakText(hello.greeting, 0, epoch);
      }
    } catch (error) {
      if (this.epoch !== epoch) return;
      const message = error.name === "NotAllowedError" ? "麦克风权限未开启，请允许后重新开始通话。"
        : error.name === "NotFoundError" ? "没有找到麦克风，请连接麦克风后重试。"
        : error.message || "通话连接失败，请重试。";
      this.fail(message);
    }
  }

  connectSocket(epoch) {
    return new Promise((resolve, reject) => {
      const url = `${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/api/call`;
      const socket = new WebSocket(url); this.socket = socket;
      let ready = false;
      const timeout = setTimeout(() => { reject(new Error("客服连接超时，请重试。")); socket.close(); }, 15000);
      socket.onmessage = event => {
        if (this.epoch !== epoch) return;
        let message;
        try { message = JSON.parse(event.data); } catch (_) { return; }
        if (message.type === "ready") { ready = true; clearTimeout(timeout); resolve(message); return; }
        if (message.type === "error" && !ready) { clearTimeout(timeout); reject(new Error(message.message)); return; }
        this.onMessage(message, epoch);
      };
      socket.onerror = () => { clearTimeout(timeout); if (!ready) reject(new Error("无法建立语音连接，请重试。")); };
      socket.onclose = () => {
        clearTimeout(timeout);
        if (!ready) reject(new Error("客服暂时无法接通，请稍后重试。"));
        if (this.active && this.epoch === epoch) this.fail("通话连接已断开，请重新开始通话。");
      };
    });
  }

  onAudio(frame, epoch) {
    if (!this.active || this.epoch !== epoch || !this.vad) return;
    // Only accept microphone turns while listening. Noise and speaker echo
    // must not create a request that supersedes the reply being delivered.
    if (this.awaitingReply || this.speaking || this.previews?.some(player => !player.paused)
        || performance.now() < this.pauseUntil) return;
    const volume = Math.min(1, rms(frame) * 15);
    document.documentElement.style.setProperty("--level", volume.toFixed(3));
    for (const event of this.vad.feed(frame)) this.handleAudioEvent(event, "自动发送");
  }

  handleAudioEvent(event, trigger) {
    if (!event) return;
    if (event.type === "start") {
      this.phase("recording", "说完会自动发送，也可以点「说完了，发送」。");
    } else if (event.type === "utterance") {
      if (this.socket?.readyState !== WebSocket.OPEN || this.socket.bufferedAmount >= 2_000_000) {
        this.fail("语音连接不稳定，请重新开始通话。");
        return;
      }
      const wav = encodeWav(event.samples, this.context.sampleRate);
      this.turn++;
      this.awaitingReply = true;
      this.send({ type: "utterance", id: this.turn });
      this.socket.send(wav);
      this.showInputClip(wav, trigger);
      document.documentElement.style.setProperty("--level", "0");
      this.phase("thinking", "已听到您的问题，请稍候。");
    } else if (event.type === "discard") {
      this.phase("listening", "这段声音太短，请再说一次。");
    }
  }

  onMessage(message, epoch) {
    if (!this.active || this.epoch !== epoch) return;
    if (message.id != null && message.id !== this.turn) return;
    if (message.type === "thinking") {
      this.phase("thinking", "正在为您整理回复。");
    } else if (message.type === "reply") {
      this.awaitingReply = false;
      this.showInputTokens(message.input_tokens);
      this.showReply(message.text || "");
      if (message.audio) this.playAudio(message.audio, message.id, epoch);
      else if (message.text) this.speakText(message.text, message.id, epoch);
      else this.phase("listening", "我在听，您可以继续说话。");
    } else if (message.type === "error") {
      this.awaitingReply = false;
      this.phase("listening", message.message || "这次没有听清，请再说一次。");
    } else if (message.type === "input_audio") {
      $("decode-input").disabled = false;
      $("decode-status").textContent = message.message || "已解码，可以播放。";
      if (message.audio) this.setPreview($("decoded-input"), decodeBase64(message.audio));
    }
  }

  setPreview(player, wav) {
    const previous = player.getAttribute("src");
    player.pause();
    if (previous) URL.revokeObjectURL(previous);
    if (wav) player.src = URL.createObjectURL(new Blob([wav], { type: "audio/wav" }));
    else player.removeAttribute("src");
    player.hidden = !wav;
    player.load();
  }

  clearInput() {
    for (const player of this.previews) this.setPreview(player, null);
    $("input-check").hidden = true;
    $("input-token-details").hidden = true;
    $("input-tokens").textContent = "";
    $("decode-status").textContent = "";
    $("decode-input").disabled = true;
  }

  showInputClip(wav, trigger) {
    this.clearInput();
    this.setPreview($("input-recording"), wav);
    $("input-meta").textContent = `第 ${this.turn} 轮 · ${((wav.byteLength - 44) / 32000).toFixed(1)} 秒 · ${trigger}`;
    $("input-check").hidden = false;
  }

  showInputTokens(tokens) {
    if (!Array.isArray(tokens) || !tokens.length) return;
    $("input-token-summary").textContent = `语音 token（${tokens.length} 个）`;
    $("input-tokens").textContent = tokens.join(" ");
    $("input-token-details").hidden = false;
    $("decode-input").disabled = false;
  }

  showReply(text) { $("reply").textContent = text; $("reply").hidden = !text; }
  send(message) { if (this.socket?.readyState === WebSocket.OPEN) this.socket.send(JSON.stringify(message)); }

  async playAudio(encoded, turn, epoch) {
    for (const preview of this.previews ?? []) preview.pause();
    this.stopPlayback();
    const token = ++this.playToken;
    this.speaking = true;
    try {
      const bytes = decodeBase64(encoded);
      const buffer = await this.context.decodeAudioData(bytes.buffer);
      if (!this.active || this.epoch !== epoch || this.turn !== turn || this.playToken !== token) return;
      await this.context.resume();
      if (!this.active || this.epoch !== epoch || this.turn !== turn || this.playToken !== token) return;
      const player = this.context.createBufferSource(); player.buffer = buffer;
      player.connect(this.context.destination); this.player = player;
      this.phase("speaking", "请听完回复后再继续提问。");
      player.onended = () => this.playbackEnded(token, epoch);
      player.start();
    } catch (_) {
      if (this.active && this.epoch === epoch && this.turn === turn && this.playToken === token) {
        const text = $("reply").textContent;
        if (text) this.speakText(text, turn, epoch);
        else {
          this.playbackEnded(token, epoch);
          this.phase("listening", "这次的语音无法播放，请再问一次。");
        }
      }
    }
  }

  speakText(text, turn, epoch) {
    if (!text || !this.active || this.epoch !== epoch || this.turn !== turn) return;
    for (const preview of this.previews ?? []) preview.pause();
    this.stopPlayback();
    if (!("speechSynthesis" in window)) { this.phase("listening", "您可以继续说话。"); return; }
    const token = ++this.playToken;
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = this.language || "zh-CN"; utterance.rate = 1.02;
    const voice = speechSynthesis.getVoices().find(item => item.lang.startsWith(utterance.lang.slice(0, 2)) && item.localService);
    if (voice) utterance.voice = voice;
    utterance.onend = () => this.playbackEnded(token, epoch);
    utterance.onerror = () => this.playbackEnded(token, epoch);
    this.speaking = true; this.phase("speaking", "请听完回复后再继续提问。");
    speechSynthesis.speak(utterance);
  }

  playbackEnded(token, epoch) {
    if (!this.active || this.epoch !== epoch || this.playToken !== token) return;
    this.speaking = false; this.player = null;
    this.pauseUntil = performance.now() + 180;
    if (!this.vad?.active) this.phase("listening", "我在听，您可以继续说话。");
  }

  stopPlayback() {
    this.playToken++; this.speaking = false;
    if (this.player) { this.player.onended = null; try { this.player.stop(); } catch (_) {} this.player.disconnect(); this.player = null; }
    if ("speechSynthesis" in window) speechSynthesis.cancel();
  }

  updateTimer() {
    const seconds = Math.floor((Date.now() - this.startedAt) / 1000);
    $("timer").textContent = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
  }

  fail(message) {
    this.stop(); this.phase("error", message);
    $("button-label").textContent = "重新开始";
  }

  stop() {
    this.active = false; this.epoch++;
    this.awaitingReply = false;
    for (const preview of this.previews ?? []) preview.pause();
    $("decode-input").disabled = true;
    this.stopPlayback(); this.send({ type: "hangup" });
    if (this.socket) { this.socket.onclose = null; this.socket.close(); this.socket = null; }
    if (this.capture) { this.capture.port.onmessage = null; this.capture.disconnect(); this.capture = null; }
    if (this.source) { this.source.disconnect(); this.source = null; }
    if (this.silent) { this.silent.disconnect(); this.silent = null; }
    if (this.stream) { this.stream.getTracks().forEach(track => track.stop()); this.stream = null; }
    if (this.context) { this.context.close().catch(() => {}); this.context = null; }
    this.vad = null; clearInterval(this.timer);
    document.documentElement.style.setProperty("--level", "0");
    $("call-button").disabled = false; $("button-label").textContent = "开始通话";
    this.phase("idle", "通话已结束，您可以再次开始。");
  }
}

if (typeof document !== "undefined") new VoiceCall();
